<?php $assetRoot = $assetRoot ?? '..'; ?>
<div class="toast-stack" id="toastStack" aria-live="polite"></div>
<script src="<?php echo $assetRoot; ?>/assets/js/toast-notifications.js" defer></script>
<script src="<?php echo $assetRoot; ?>/assets/js/loading-overlay.js" defer></script>
<script src="<?php echo $assetRoot; ?>/assets/js/logout-confirmation.js" defer></script>
<script src="<?php echo $assetRoot; ?>/assets/js/dashboard-action-notifications.js" defer></script>
<?php foreach ($extraScripts ?? [] as $src): ?>
<script src="<?php echo htmlspecialchars($src, ENT_QUOTES, 'UTF-8'); ?>" defer></script>
<?php endforeach; ?>
</body>

</html>
