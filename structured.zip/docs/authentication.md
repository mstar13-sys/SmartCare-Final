# Authentication and request flow

- `index.php` loads `app/bootstrap.php` and redirects to login or the user's role dashboard.
- `auth/login.php` renders login and signup panels. `auth/signup.php` redirects to the signup panel; `auth/forgot-password.php` renders the recovery form.
- `app/bootstrap.php` starts page sessions, creates CSRF tokens, handles logout, and maps roles to dashboard URLs.
- `includes/` contains the header, footer, and brand panel. Browser files live in `assets/css/` and `assets/js/`.
- Forms declare POST actions under `api/auth/`. The form scripts validate inputs and submit FormData asynchronously to the declared action, including the hidden CSRF token.
- Endpoints load `app/helpers/request.php`, `app/helpers/validators.php`, and `config/database.php` for sessions, JSON responses, CSRF checks, validation, and PDO.
- Successful login returns a dashboard URL relative to the authentication page. Roles map to `dashboard/patient/index.php`, `dashboard/staff/index.php`, or `dashboard/superadmin/index.php`.
- `login-notification-events.js` handles login events; `toast-notifications.js` supplies feedback. `loading-overlay.js` and `logout-confirmation.js` handle operation feedback and logout confirmation. Password visibility and strength use shared scripts.
- The superadmin dashboard declares `api/superadmin.php` as its API and form target. The endpoint retains its role checks, CSRF protection, prepared SQL, and auditing.

Forgot-password currently checks the submitted account and returns feedback; delivery of reset email and completion of a token-based reset are not implemented. Patient and staff quick actions remain demonstration UI.
