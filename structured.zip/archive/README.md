# Archived files

These files are preserved for reference and are not loaded by the application. Exclude this directory from deployment.

- `smartcare-complete.zip`: original supplied project archive, unchanged.
- `legacy-js/`: five scripts with no references in the current application. Active notification implementations remain in `assets/js/`.
- `legacy-php/database-connection.php.txt`: unused database connection, preserved as non-executable text. Active settings live in `config/database.php`.
- `database/smartcare-previous.sql`: previous nested schema, unchanged. It creates `smartcare` but selects `smartcare_db`; do not use it for setup. The former root schema now lives at `database/schema.sql` and includes broader profile provisioning.
