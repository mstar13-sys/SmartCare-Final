# SmartCare

PHP/MySQL clinic portal with patient, staff, and superadmin dashboards. No build step is required.

## Project structure

```text
api/                  JSON endpoints
  auth/               Login, signup, and forgot-password handlers
  superadmin.php      Protected administration endpoint
app/                  Shared server-side code
  bootstrap.php       Page sessions, CSRF token, logout, role routing
  helpers/            Request handling and validation
assets/
  css/                Stylesheets
  js/                 Active browser scripts
auth/                 Authentication pages
config/
  database.php        Active PDO connection settings
dashboard/            Role-specific pages
  patient/index.php
  staff/index.php
  superadmin/index.php
database/
  schema.sql          Canonical smartcare_db schema
  migrations/         Existing-installation migrations
docs/                 Architecture and database documentation
includes/             Shared HTML templates
archive/              Historical files; exclude from deployment
index.php             Application entry point and role redirect
```

## Run locally

1. Configure MySQL credentials in `config/database.php` (currently port 3307, database `smartcare_db`).
2. For a fresh installation, open the MySQL client from the project root and run `SOURCE database/schema.sql;`.
3. For an original legacy installation, consult `docs/database-schema.md` before importing. Do not import files from `archive/`.
4. Run `php -S localhost:8000` from the project root and visit http://localhost:8000.

The seeded patient login is `demo@smartcare.com` / `Demo1234!`.

## Naming conventions

Use lowercase folder names and kebab-case filenames. Group files by responsibility; use role names consistently (`patient`, `staff`, `superadmin`). Each role dashboard starts at `index.php`. Keep shared markup in `includes/`, reusable PHP logic in `app/`, and browser assets in `assets/`.

Forms and JavaScript use the endpoints under `api/`. Update callers whenever an endpoint or asset moves. Dashboard URLs now use `dashboard/{role}/index.php`; old dashboard and `php/` URLs have been replaced.

See [authentication wiring](docs/authentication.md), [database schema](docs/database-schema.md), and [archived files](archive/README.md).
